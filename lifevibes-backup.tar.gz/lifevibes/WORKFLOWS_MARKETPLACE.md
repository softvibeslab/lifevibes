# Marketplace de Habilidades and Workflows n8N - Softvibes Edition
# Marketplace de Habilidades and Workflows n8N - Softvibes Edition

## Vision
Crear un marketplace de habilidades y workflows integrado con n8N.

## Concepto Clave
Superpoderes = Habilidades del Marketplace
