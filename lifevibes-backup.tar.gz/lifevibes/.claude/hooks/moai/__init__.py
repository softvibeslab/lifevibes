"""
Alfred Hooks Package

This package contains Alfred-specific hook scripts for MoAI-ADK integration.
"""

__version__ = "1.0.0"
__author__ = "MoAI-ADK Team"
